#!/usr/bin/env python3
"""Check research citations and explicitly transcribed arithmetic, not source truth."""
import csv
import datetime
import json
import hashlib
import re
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
text = (ROOT / 'paper.md').read_text()
body, refs = text.split('## References')
used = set(re.findall(r'\[\^(\d+)\]', body))
defined = set(re.findall(r'^\[\^(\d+)\]:', refs, re.M))
assert used == defined, (used - defined, defined - used)
with (ROOT / 'source-register.csv').open() as f:
    register = list(csv.DictReader(f))
ids = [r['source_id'] for r in register]
assert len(ids) == len(set(ids))
assert {'S' + x for x in used} <= set(ids)
tex = (ROOT / 'paper.tex').read_text()
tex_used = set(re.findall(r'\\cite\{(S\d+)\}', tex))
tex_defined = set(re.findall(r'\\bibitem\[S\d+\]\{(S\d+)\}', tex))
assert tex_used == tex_defined == {'S' + x for x in used}
# Check that the existing editor document and prose companion agree without rewriting either.
import importlib.util
spec = importlib.util.spec_from_file_location('paper_render', ROOT / 'build-paper.py')
render = importlib.util.module_from_spec(spec)
spec.loader.exec_module(render)
for para in body.split('\n\n'):
    if para.strip() and not para.startswith('#') and not para.startswith('Research working paper by'):
        assert render.inline(para) in tex, para[:100]
assert 'Version 1.0, 3 October 2026' in tex

with (ROOT / 'allocations.csv').open() as f:
    rows = list(csv.DictReader(f))
for year, expected_total, funded, unawarded, scholarship in [
    ('2023/24', 39000, 15, 1, 8000), ('2024/25', 36000, 14, 0, 7000),
    ('2025/26', 18000, 15, 0, 6000), ('2026/27', 28000, 18, 5, 6000)
]:
    group = [r for r in rows if r['financial_year'] == year]
    total = sum(Decimal(r['allocation_gbp']) for r in group)
    assert total == expected_total, (year, total)
    assert sum(Decimal(r['allocation_gbp']) > 0 for r in group) == funded
    assert sum(Decimal(r['allocation_gbp']) == 0 for r in group) == unawarded
    print(year, 'Appendix A:', total, '; plus scholarship allocation:', total + scholarship,
          '; positive applicant entries:', funded)
assert sum(Decimal(r['allocation_gbp']) > Decimal(r['bid_gbp']) for r in rows if r['financial_year'] == '2023/24') == 3
assert sum(Decimal(r['bid_gbp']) for r in rows if r['financial_year'] == '2023/24' and r['category'] == 'Voluntary') == Decimal('31772.56')
assert sum(Decimal(r['bid_gbp']) for r in rows if r['financial_year'] == '2024/25' and r['category'] == 'Voluntary') == Decimal('13200')
assert datetime.date(1929, 7, 3).strftime('%A') == 'Wednesday'
assert datetime.date(1929, 6, 30).strftime('%A') == 'Sunday'
assert 971073 - 961842 == 9231
assert 43000 + 6314 == 49314
assert 1700 + 2000 != 3900
print('Calendar and reconciliation arithmetic checked; no source discrepancies resolved by this script.')
print('Citation coverage:', len(used), 'references;', len(register), 'registered sources.')
print('Paper words including references:', len(text.split()))

# Independent controls transcribed from the four official Appendix A schedules.
category_controls = {
    '2023/24': (12500, 12500, 4000, 10000),
    '2024/25': (11700, 11700, 3600, 9000),
    '2025/26': (4000, 4000, 3000, 7000),
    '2026/27': (5000, 5000, 5000, 13000),
}
assert len(rows) == 68
assert len({(r['financial_year'], r['category'], r['applicant_as_recorded']) for r in rows}) == 68
assert {r['category'] for r in rows} == {'LCC', 'BBC', 'Mechanics', 'Voluntary'}
for year, controls in category_controls.items():
    for category, expected in zip(('LCC', 'BBC', 'Mechanics', 'Voluntary'), controls):
        actual = sum(Decimal(r['allocation_gbp']) for r in rows
                     if r['financial_year'] == year and r['category'] == category)
        assert actual == expected, (year, category, actual)
for year, expected in [('2025/26', '22604'), ('2026/27', '37252')]:
    assert sum(Decimal(r['bid_gbp']) for r in rows if r['financial_year'] == year
               and r['category'] == 'Voluntary') == Decimal(expected)
appendix_ids = {'2023/24': 'S57', '2024/25': 'S59', '2025/26': 'S18', '2026/27': 'S20'}
for row in rows:
    assert row['source_id'] == appendix_ids[row['financial_year']]
    assert row['source_page'] in {'1', '2'}
    assert Decimal(row['allocation_gbp']) >= 0 and Decimal(row['bid_gbp']) >= 0

# The bundle flattens prepared support files beside the manuscript.
support = ROOT / 'publication' if (ROOT / 'publication').is_dir() else ROOT
with (support / 'allocation-summary.csv').open() as f:
    summaries = list(csv.DictReader(f))
assert len(summaries) == 4
assert {r['financial_year'] for r in summaries} == set(appendix_ids)
for summary in summaries:
    group = [r for r in rows if r['financial_year'] == summary['financial_year']]
    total = sum(Decimal(r['allocation_gbp']) for r in group)
    assert total == Decimal(summary['non_scholarship_allocations_gbp'])
    assert total + Decimal(summary['scholarship_category_gbp']) == Decimal(summary['reported_total_gbp'])
    assert sum(Decimal(r['allocation_gbp']) > 0 for r in group) == int(summary['positive_applicant_rows'])
    assert sum(Decimal(r['allocation_gbp']) == 0 for r in group) == int(summary['zero_applicant_rows'])
    assert summary['appendix_source_id'] == appendix_ids[summary['financial_year']]
    assert {summary[k] for k in ('appendix_source_id', 'report_source_id', 'decision_source_id')} <= set(ids)
    datetime.date.fromisoformat(summary['approval_date'])
with (support / 'fact-check.csv').open() as f:
    checks = list(csv.DictReader(f))
assert len(checks) == len({r['check_id'] for r in checks}) == 55
check_sources = {sid for r in checks for sid in r['source_ids'].split(';')}
assert check_sources == tex_used, (check_sources - tex_used, tex_used - check_sources)
metadata = json.loads((support / 'zenodo-metadata.json').read_text())
abstract = body.split('## Abstract')[1].split('## 1.')[0].strip()
assert metadata['description'].split('\n\n')[0] == abstract
assert metadata['version'] == '1.0'
assert metadata['publication_date'] == '2026-10-03'
assert re.fullmatch(r'10\.5281/zenodo\.\d+', metadata['doi']), metadata['doi']
assert f"https://doi.org/{metadata['doi']}" in tex and f"https://doi.org/{metadata['doi']}" in text
assert metadata['license'] == 'cc-by-4.0'
print('Category controls, bid totals, source mappings and review-support consistency passed.')

# Bind the visually inspected PDF to the exact source bytes used for its build.
# The record documents a review; hashes detect stale files, not historical truth.
build_record = support / 'pdf-build.json'
if build_record.exists():
    build = json.loads(build_record.read_text())
    assert build['source_sha256'] == hashlib.sha256((ROOT / 'paper.tex').read_bytes()).hexdigest()
    pdf_name = build['pdf_filename']
    assert Path(pdf_name).name == pdf_name
    assert build['pdf_sha256'] == hashlib.sha256((support / pdf_name).read_bytes()).hexdigest()
    assert build['visually_reviewed_pages'] == list(range(1, build['page_count'] + 1))
    assert build['unresolved_layout_defects'] == []
    print('PDF hashes match the reviewed source and complete page-review record.')
