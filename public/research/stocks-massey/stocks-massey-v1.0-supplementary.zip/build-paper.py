#!/usr/bin/env python3
"""Render the research prose master as one standalone LaTeX source file."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent

def esc(value):
    mapping = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
               '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}',
               '~': r'\textasciitilde{}', '^': r'\textasciicircum{}',
               '£': r'\pounds{}', '–': '--', '—': '---', '’': "'",
               '‘': '`', '“': '``', '”': "''"}
    return ''.join(mapping.get(c, c) for c in value)

TOKEN = re.compile(r'\[\^(\d+)\]|\[([^\]]+)\]\((https?://[^)]+)\)|\*\*(.+?)\*\*|\*([^*]+)\*|`([^`]+)`')

def inline(value):
    parts = []; end = 0
    for m in TOKEN.finditer(value):
        parts.append(esc(value[end:m.start()]))
        if m[1]: parts.append(r'\cite{S' + m[1] + '}')
        elif m[2]: parts.append(r'\href{' + m[3].replace('%', r'\%').replace('#', r'\#') + '}{' + inline(m[2]) + '}')
        elif m[4]: parts.append(r'\textbf{' + inline(m[4]) + '}')
        elif m[5]: parts.append(r'\emph{' + esc(m[5]) + '}')
        elif m[6]: parts.append(r'\texttt{' + esc(m[6]) + '}')
        end = m.end()
    parts.append(esc(value[end:]))
    return ''.join(parts)

def build():
    src = (ROOT / 'paper.md').read_text()
    refs = re.findall(r'^\[\^(\d+)\]: (.+)$', src, re.M)
    body = src.split('## References')[0].splitlines()
    out = [r'''\documentclass[11pt,a4paper]{article}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage[margin=26mm]{geometry}
\usepackage{microtype}
\usepackage{xcolor}
\usepackage{hyperref}
\hypersetup{colorlinks=true,urlcolor=blue!45!black,citecolor=blue!45!black,linkcolor=black,
pdftitle={The Price of a Civic Legacy},pdfauthor={Tom Pickup}}
\setlength{\parskip}{5pt}
\setlength{\parindent}{0pt}
\linespread{1.07}
\emergencystretch=2em
\clubpenalty=10000
\widowpenalty=10000
\displaywidowpenalty=10000
\title{\textbf{The Price of a Civic Legacy}\\[7pt]\large Edward Stocks Massey, brewing wealth and the making of public culture in Burnley}
\author{Tom Pickup}
\date{Version 1.0, 3 October 2026\\[3pt]\small\href{https://doi.org/10.5281/zenodo.23124513}{doi:10.5281/zenodo.23124513}}
\begin{document}
\maketitle
''']
    abstract = False
    for line in body:
        if line.startswith('# ') or line.startswith('## Edward') or line.startswith('Research working paper by'):
            continue
        if line == '## Abstract':
            out.append(r'\begin{abstract}'); abstract = True
        elif line.startswith('## '):
            if abstract: out.append(r'\end{abstract}'); abstract = False
            heading = re.sub(r'^\d+\.\s*', '', line[3:])
            star = '*' if heading == 'Research and authorship note' else ''
            out.append(r'\section' + star + '{' + esc(heading) + '}')
        else:
            out.append(inline(line))
    out.append(r'\small\begin{thebibliography}{S61}\raggedright')
    for key, ref in refs:
        out.append(r'\bibitem[S' + key + ']{S' + key + '} ' + inline(ref))
    out.extend([r'\end{thebibliography}', r'\end{document}'])
    (ROOT / 'paper.tex').write_text('\n'.join(out) + '\n')
    print('Wrote standalone paper.tex with', len(refs), 'references')

if __name__ == '__main__':
    build()
