THE PRICE OF A CIVIC LEGACY: SUPPLEMENTARY MATERIALS
Edward Stocks Massey, brewing wealth and the making of public culture in Burnley
Tom Pickup | Version 1.0 | First made public 3 October 2026
DOI: 10.5281/zenodo.23124513 (https://doi.org/10.5281/zenodo.23124513)

STATUS
Unreviewed working paper. It has not been peer reviewed. It offers a selective,
source-critical interpretation of public evidence, not a comprehensive
institutional or financial history of the Edward Stocks Massey Bequest Fund.
The reading copy is stocks-massey-v1.0.pdf, deposited beside this package.

CONTENTS
stocks-massey-v1.0.pdf: the 16-page paper, compiled from paper.tex.
paper.tex: LaTeX source of the paper (the master text).
paper.md: Markdown text of the same paper, synchronised with paper.tex.
allocations.csv: 68 applicant rows from the four published Appendix A
  allocation schedules, 2023/24 to 2026/27 (62 positive, six zero).
  Individual scholarships are not applicant rows and are excluded.
allocation-summary.csv: yearly totals, row counts, approval dates, source IDs.
data-dictionary.txt: coverage, field meanings and transcription decisions.
source-register.csv: the 55 cited sources, with what was actually consulted.
fact-check.csv: 55 claim-level checks with locators and remaining limits.
pdf-build.json: source and PDF hashes, compiler and page-review record.
zenodo-metadata.json: the descriptive metadata used for this deposit.
verify-research.py: checks citations, synchronisation, totals and hashes.
build-paper.py: regenerates paper.tex from paper.md (used by the checks).
LICENSE.txt: licence terms and their limits.
SHA256SUMS.txt: SHA-256 hashes of every other file in the package.

HOW TO CHECK
In an extracted copy, run: python3 verify-research.py
Python 3.9 or later; no third-party packages. The script checks that every
citation is defined, that paper.md and paper.tex agree, that the allocation
rows reproduce the published totals and counts, selected calendar and
arithmetic points, and that the PDF matches the hashes in pdf-build.json.
It does not authenticate the history or reconcile the charity's accounts.

WHAT THE CHECKS DO NOT CERTIFY
A source's printing is not proof that its account is correct. Catalogue
metadata is not inspection of the original record. Allocations are approved
amounts, not payments or audited expenditure. The original gift's amount,
any licence-related deductions, the wording of the will and the 1977 scheme,
and the long-run impact of the fund remain unresolved and are bounded in the
paper. The original will, the 1977 scheme, the executors' books (Lancashire
Archives DDX1101/74/12), the Joint Committee minutes and the earlier local
histories by Spencer (1981) and Chapples (2009) have not been read.

THE BEQUEST FIGURES
The paper keeps three figures apart and does not reconcile them: £135,000 in
later council accounts of the gift; a gross estate of £123,563 and an
approximate Burnley residue of £90,000 in a contemporary report of 1910.
Massey died in 1909, the will was proved in 1910, and income was reported as
becoming available to the gallery in 1921.

AUTHOR INTEREST
Tom Pickup is a Lancashire County Council representative on the Edward
Stocks Massey Bequest Fund Joint Advisory Committee and its chair. The paper
is personal research; no endorsement by the committee, the trustees or either
council is claimed.

AI ASSISTANCE
The research used AI assistance for searching, transcription comparison,
drafting and editing. The verification files record preparation checks, not
independent scholarly peer review.

RIGHTS AND PERSONAL INFORMATION
The author's text and original research data are released under CC BY 4.0;
see LICENSE.txt. Third-party sources are cited, not redistributed: no source
PDFs, newspaper images, photographs, book extracts or private correspondence
are included. The allocation data transcribes published council schedules;
names printed there are retained as printed, and no private data is added.

CITATION
Pickup, T. (2026) The Price of a Civic Legacy: Edward Stocks Massey, brewing
wealth and the making of public culture in Burnley. Working paper, version 1.0.
Zenodo. DOI: 10.5281/zenodo.23124513.
